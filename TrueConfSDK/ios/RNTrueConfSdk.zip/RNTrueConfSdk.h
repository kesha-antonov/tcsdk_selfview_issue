
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
#import <TrueConfSDK/TrueConfSDK.h>
#import <React/RCTLog.h>

@interface RNTrueConfSdk : RCTEventEmitter <RCTBridgeModule>

@end
  
