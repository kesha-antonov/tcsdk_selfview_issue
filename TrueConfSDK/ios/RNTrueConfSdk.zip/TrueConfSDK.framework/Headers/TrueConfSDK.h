//
//  TrueConfSDK.h
//
//  Copyright © 2016 TrueConf. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TrueConfSDKFW.
FOUNDATION_EXPORT double TrueConfSDKFWVersionNumber;

//! Project version string for TrueConfSDKFW.
FOUNDATION_EXPORT const unsigned char TrueConfSDKFWVersionString[];

#import <TrueConfSDK/TrueConf.h>
#import <TrueConfSDK/TCTheme.h>
